Project Gutenberg
==============
This collection of files contains texts taken from the UTF-8 representations at Project Gutenberg: http://www.gutenberg.org/wiki/Main_Page.

# Mary Shelley, *Frankenstein*
Original URL: http://www.gutenberg.org/ebooks/42324.txt.utf-8
Pre-Processing: Project Gutenberg boilerplate has been removed from the beginning and 
end of the file.