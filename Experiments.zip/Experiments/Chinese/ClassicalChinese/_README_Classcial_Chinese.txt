Classical Chinese

Sample Tests:
- 红楼梦HongLouMeng_Dream_of_the_Red Chamber/
- 鸿门宴_通假字ChineseConsolidations/
- 诗词歌赋The_Poems_And_Songs/