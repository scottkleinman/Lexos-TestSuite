File to use: 红楼梦HongLouMeng_Dream_of_the_Red Chamber folder

This is a example of using the similarity query to find out how close chapter 67
is to all the other chapters in the book.

================================================================================
STEP0: Upload all files in 红楼梦HongLouMeng_Dream_of_the_Red Chamber folder
================================================================================
STEP1: Scrub using default settings, although it it not required for this exp.
    -Remove Digits
================================================================================
STEP2: Similarity Query Rankings
    -Click Chapter67 which is use to compare with all other files
    -Token Type = by Characters 1 gram
    -Deselect the Remove words that only appear once option (optional)

*We could notice in the result ranking table that Chapter 64 is the closest one 
to Chapter 67. Also, we discovered that Chapter 67 is littble bit closer to the 
late 40 chapters, which is known written by another person than the first 80 
chapters. Thus, it collapse with the thought of chatper 67 and chapter 64 might 
be written with the same author as the late 40 chapter. 


================================================================================
================================================================================

    
JL 7/02/15
